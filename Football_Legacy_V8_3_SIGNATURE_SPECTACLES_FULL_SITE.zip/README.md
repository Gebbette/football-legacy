Football Legacy Multiplayer Quick Story V6 — synchronized season/reveal gate fix.
